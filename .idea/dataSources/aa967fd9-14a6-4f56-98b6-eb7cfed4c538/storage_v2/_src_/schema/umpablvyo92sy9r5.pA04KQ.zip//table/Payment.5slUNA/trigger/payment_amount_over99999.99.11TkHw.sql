create definer = bntn0fyumq6q1tuz@`%` trigger `payment_amount_over99999.99`
    before insert
    on Payment
    for each row
BEGIN 
IF NEW.amount>99999.99 THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'amount out of range';
 END IF; 
 END;

