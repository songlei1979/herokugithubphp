create definer = bntn0fyumq6q1tuz@`%` trigger ward_location_empty
    before insert
    on Ward
    for each row
BEGIN 
IF NEW.location = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'location is empty';
 END IF; 
 END;

