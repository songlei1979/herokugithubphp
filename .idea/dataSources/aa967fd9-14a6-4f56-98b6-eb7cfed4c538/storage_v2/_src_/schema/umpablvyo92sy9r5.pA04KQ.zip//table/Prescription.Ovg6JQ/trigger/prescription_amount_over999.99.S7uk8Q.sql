create definer = bntn0fyumq6q1tuz@`%` trigger `prescription_amount_over999.99`
    before insert
    on Prescription
    for each row
BEGIN 
IF NEW.amount>999.99 THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'amount out of range';
 END IF; 
 END;

