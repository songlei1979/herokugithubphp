create definer = bntn0fyumq6q1tuz@`%` trigger ward_capacity_below1
    before insert
    on Ward
    for each row
BEGIN 
IF NEW.capacity<1 THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'capacity out of range';
 END IF; 
 END;

