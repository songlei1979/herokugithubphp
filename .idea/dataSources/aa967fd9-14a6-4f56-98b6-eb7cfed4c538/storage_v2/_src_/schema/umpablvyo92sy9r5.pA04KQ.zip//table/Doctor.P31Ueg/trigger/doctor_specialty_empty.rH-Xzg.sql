create definer = bntn0fyumq6q1tuz@`%` trigger doctor_specialty_empty
    before insert
    on Doctor
    for each row
BEGIN 
IF NEW.specialty = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'specialty is empty';
 END IF; 
 END;

