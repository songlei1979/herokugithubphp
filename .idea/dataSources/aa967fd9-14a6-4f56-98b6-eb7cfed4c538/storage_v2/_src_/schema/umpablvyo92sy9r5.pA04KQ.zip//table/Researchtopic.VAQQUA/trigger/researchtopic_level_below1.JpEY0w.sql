create definer = bntn0fyumq6q1tuz@`%` trigger researchtopic_level_below1
    before insert
    on Researchtopic
    for each row
BEGIN 
IF NEW.level<1 THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'level out of range';
 END IF; 
 END;

