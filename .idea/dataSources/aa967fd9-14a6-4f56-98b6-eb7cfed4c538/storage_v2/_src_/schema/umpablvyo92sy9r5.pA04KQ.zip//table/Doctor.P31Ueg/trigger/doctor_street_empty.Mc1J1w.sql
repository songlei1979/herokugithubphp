create definer = bntn0fyumq6q1tuz@`%` trigger doctor_street_empty
    before insert
    on Doctor
    for each row
BEGIN 
IF NEW.street = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'street is empty';
 END IF; 
 END;

