create definer = bntn0fyumq6q1tuz@`%` trigger doctor_phone_empty
    before insert
    on Doctor
    for each row
BEGIN 
IF NEW.phone = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'phone is empty';
 END IF; 
 END;

