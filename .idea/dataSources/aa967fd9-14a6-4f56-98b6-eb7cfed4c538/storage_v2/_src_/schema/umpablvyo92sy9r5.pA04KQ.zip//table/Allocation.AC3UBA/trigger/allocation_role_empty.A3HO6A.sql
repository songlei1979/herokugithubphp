create definer = bntn0fyumq6q1tuz@`%` trigger allocation_role_empty
    before insert
    on Allocation
    for each row
BEGIN 
IF NEW.role = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'role is empty';
 END IF; 
 END;

