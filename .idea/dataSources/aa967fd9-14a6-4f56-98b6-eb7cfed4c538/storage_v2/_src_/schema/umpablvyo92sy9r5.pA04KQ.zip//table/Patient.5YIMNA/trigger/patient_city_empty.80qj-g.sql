create definer = bntn0fyumq6q1tuz@`%` trigger patient_city_empty
    before insert
    on Patient
    for each row
BEGIN 
IF NEW.city = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'city is empty';
 END IF; 
 END;

