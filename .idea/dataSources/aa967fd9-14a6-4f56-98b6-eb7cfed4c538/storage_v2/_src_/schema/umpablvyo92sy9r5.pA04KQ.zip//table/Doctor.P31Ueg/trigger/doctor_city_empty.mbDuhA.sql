create definer = bntn0fyumq6q1tuz@`%` trigger doctor_city_empty
    before insert
    on Doctor
    for each row
BEGIN 
IF NEW.city = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'city is empty';
 END IF; 
 END;

