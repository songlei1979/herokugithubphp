create definer = bntn0fyumq6q1tuz@`%` trigger `doctor_salary_over200000.00`
    before insert
    on Doctor
    for each row
BEGIN 
IF NEW.salary>200000.00 THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'salary out of range';
 END IF; 
 END;

