create definer = bntn0fyumq6q1tuz@`%` trigger patient_suburb_empty
    before insert
    on Patient
    for each row
BEGIN 
IF NEW.suburb = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'suburb is empty';
 END IF; 
 END;

