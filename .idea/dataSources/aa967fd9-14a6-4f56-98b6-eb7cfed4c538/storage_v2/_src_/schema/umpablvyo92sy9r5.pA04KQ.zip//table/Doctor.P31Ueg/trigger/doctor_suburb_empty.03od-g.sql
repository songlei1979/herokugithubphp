create definer = bntn0fyumq6q1tuz@`%` trigger doctor_suburb_empty
    before insert
    on Doctor
    for each row
BEGIN 
IF NEW.suburb = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'suburb is empty';
 END IF; 
 END;

