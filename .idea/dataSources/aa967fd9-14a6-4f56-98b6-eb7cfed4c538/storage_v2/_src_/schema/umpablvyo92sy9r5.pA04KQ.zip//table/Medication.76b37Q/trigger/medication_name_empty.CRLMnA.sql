create definer = bntn0fyumq6q1tuz@`%` trigger medication_name_empty
    before insert
    on Medication
    for each row
BEGIN 
IF NEW.name = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'name is empty';
 END IF; 
 END;

