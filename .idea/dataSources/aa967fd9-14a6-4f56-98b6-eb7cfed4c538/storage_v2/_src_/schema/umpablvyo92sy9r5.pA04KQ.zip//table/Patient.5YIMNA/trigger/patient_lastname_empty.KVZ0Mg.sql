create definer = bntn0fyumq6q1tuz@`%` trigger patient_lastname_empty
    before insert
    on Patient
    for each row
BEGIN 
IF NEW.lastname = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'lastname is empty';
 END IF; 
 END;

