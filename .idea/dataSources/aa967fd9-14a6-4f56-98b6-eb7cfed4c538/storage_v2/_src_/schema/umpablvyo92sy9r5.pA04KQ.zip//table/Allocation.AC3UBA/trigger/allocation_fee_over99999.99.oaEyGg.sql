create definer = bntn0fyumq6q1tuz@`%` trigger `allocation_fee_over99999.99`
    before insert
    on Allocation
    for each row
BEGIN 
IF NEW.fee>99999.99 THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'fee out of range';
 END IF; 
 END;

