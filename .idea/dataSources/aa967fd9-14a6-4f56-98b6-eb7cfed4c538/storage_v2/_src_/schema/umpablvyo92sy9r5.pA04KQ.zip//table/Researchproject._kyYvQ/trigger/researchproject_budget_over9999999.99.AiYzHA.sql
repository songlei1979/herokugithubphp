create definer = bntn0fyumq6q1tuz@`%` trigger `researchproject_budget_over9999999.99`
    before insert
    on Researchproject
    for each row
BEGIN 
IF NEW.budget>9999999.99 THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'budget out of range';
 END IF; 
 END;

