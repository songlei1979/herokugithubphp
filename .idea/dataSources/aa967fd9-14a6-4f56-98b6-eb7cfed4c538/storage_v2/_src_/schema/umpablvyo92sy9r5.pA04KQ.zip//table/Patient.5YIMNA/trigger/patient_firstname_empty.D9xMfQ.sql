create definer = bntn0fyumq6q1tuz@`%` trigger patient_firstname_empty
    before insert
    on Patient
    for each row
BEGIN 
IF NEW.firstname = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'firstname is empty';
 END IF; 
 END;

