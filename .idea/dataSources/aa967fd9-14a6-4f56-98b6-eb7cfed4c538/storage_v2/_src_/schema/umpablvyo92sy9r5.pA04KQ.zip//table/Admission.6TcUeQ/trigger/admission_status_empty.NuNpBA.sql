create definer = bntn0fyumq6q1tuz@`%` trigger admission_status_empty
    before insert
    on Admission
    for each row
BEGIN 
IF NEW.status = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'status is empty';
 END IF; 
 END;

