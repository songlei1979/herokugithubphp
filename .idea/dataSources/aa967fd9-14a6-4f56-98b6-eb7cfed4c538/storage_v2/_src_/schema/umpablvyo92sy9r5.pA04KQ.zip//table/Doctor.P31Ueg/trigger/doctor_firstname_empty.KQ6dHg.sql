create definer = bntn0fyumq6q1tuz@`%` trigger doctor_firstname_empty
    before insert
    on Doctor
    for each row
BEGIN 
IF NEW.firstname = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'firstname is empty';
 END IF; 
 END;

