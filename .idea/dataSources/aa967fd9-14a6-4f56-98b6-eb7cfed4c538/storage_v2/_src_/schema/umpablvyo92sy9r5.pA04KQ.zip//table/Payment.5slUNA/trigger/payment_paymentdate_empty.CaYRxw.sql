create definer = bntn0fyumq6q1tuz@`%` trigger payment_paymentdate_empty
    before insert
    on Payment
    for each row
BEGIN 
IF NEW.paymentdate = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'paymentdate is empty';
 END IF; 
 END;

