create definer = bntn0fyumq6q1tuz@`%` trigger `doctor_salary_below20000.00`
    before insert
    on Doctor
    for each row
BEGIN 
IF NEW.salary<20000.00 THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'salary out of range';
 END IF; 
 END;

