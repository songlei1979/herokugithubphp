create definer = bntn0fyumq6q1tuz@`%` trigger prescription_prescriptiondate_empty
    before insert
    on Prescription
    for each row
BEGIN 
IF NEW.prescriptiondate = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'prescriptiondate is empty';
 END IF; 
 END;

