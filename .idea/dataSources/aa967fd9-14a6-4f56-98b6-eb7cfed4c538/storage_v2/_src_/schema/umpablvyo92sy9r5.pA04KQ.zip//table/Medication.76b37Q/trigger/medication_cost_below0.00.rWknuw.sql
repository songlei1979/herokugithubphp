create definer = bntn0fyumq6q1tuz@`%` trigger `medication_cost_below0.00`
    before insert
    on Medication
    for each row
BEGIN 
IF NEW.cost<0.00 THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'cost out of range';
 END IF; 
 END;

