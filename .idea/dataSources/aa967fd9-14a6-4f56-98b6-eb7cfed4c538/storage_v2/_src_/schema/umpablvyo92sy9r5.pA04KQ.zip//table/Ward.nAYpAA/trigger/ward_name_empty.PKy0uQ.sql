create definer = bntn0fyumq6q1tuz@`%` trigger ward_name_empty
    before insert
    on Ward
    for each row
BEGIN 
IF NEW.name = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'name is empty';
 END IF; 
 END;

