create definer = bntn0fyumq6q1tuz@`%` trigger ward_capacity_over20
    before insert
    on Ward
    for each row
BEGIN 
IF NEW.capacity>20 THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'capacity out of range';
 END IF; 
 END;

