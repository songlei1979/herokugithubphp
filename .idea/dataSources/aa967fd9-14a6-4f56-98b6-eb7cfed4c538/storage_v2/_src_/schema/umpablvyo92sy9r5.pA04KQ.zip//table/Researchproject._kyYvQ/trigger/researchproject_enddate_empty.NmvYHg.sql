create definer = bntn0fyumq6q1tuz@`%` trigger researchproject_enddate_empty
    before insert
    on Researchproject
    for each row
BEGIN 
IF NEW.enddate = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'enddate is empty';
 END IF; 
 END;

