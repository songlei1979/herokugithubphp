create definer = bntn0fyumq6q1tuz@`%` trigger `allocation_fee_below0.00`
    before insert
    on Allocation
    for each row
BEGIN 
IF NEW.fee<0.00 THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'fee out of range';
 END IF; 
 END;

