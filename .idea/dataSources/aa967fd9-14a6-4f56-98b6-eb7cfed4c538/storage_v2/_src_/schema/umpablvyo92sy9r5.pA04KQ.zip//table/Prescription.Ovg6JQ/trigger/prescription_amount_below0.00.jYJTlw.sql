create definer = bntn0fyumq6q1tuz@`%` trigger `prescription_amount_below0.00`
    before insert
    on Prescription
    for each row
BEGIN 
IF NEW.amount<0.00 THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'amount out of range';
 END IF; 
 END;

