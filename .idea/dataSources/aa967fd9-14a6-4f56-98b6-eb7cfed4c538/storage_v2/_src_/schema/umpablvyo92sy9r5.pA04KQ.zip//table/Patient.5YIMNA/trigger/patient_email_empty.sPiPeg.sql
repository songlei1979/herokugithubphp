create definer = bntn0fyumq6q1tuz@`%` trigger patient_email_empty
    before insert
    on Patient
    for each row
BEGIN 
IF NEW.email = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'email is empty';
 END IF; 
 END;

