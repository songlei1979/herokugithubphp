create definer = bntn0fyumq6q1tuz@`%` trigger admission_description_empty
    before insert
    on Admission
    for each row
BEGIN 
IF NEW.description = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'description is empty';
 END IF; 
 END;

