create definer = bntn0fyumq6q1tuz@`%` trigger researchproject_outcome_empty
    before insert
    on Researchproject
    for each row
BEGIN 
IF NEW.outcome = "" THEN 
 SIGNAL SQLSTATE '12345'
SET MESSAGE_TEXT = 'outcome is empty';
 END IF; 
 END;

